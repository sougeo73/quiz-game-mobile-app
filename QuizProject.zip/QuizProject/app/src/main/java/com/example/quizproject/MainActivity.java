package com.example.quizproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int score = 0;
    int correctanswers = 0;
    public CheckBox ageYoungCheckBox, ageAdultCheckBox, ageSeniorCheckBox;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ageYoungCheckBox = (CheckBox) findViewById(R.id.ageYoungCheckBox);
        ageAdultCheckBox = (CheckBox) findViewById(R.id.ageAdultCheckBox);
        ageSeniorCheckBox = (CheckBox) findViewById(R.id.ageSeniorCheckBox);
    }

    /**
     * This method is called on so the user can only check one checkbox at a time.
     */
    public void onCheckboxClicked(View view) {
        if (ageYoungCheckBox.isChecked()) {
            ageAdultCheckBox.setChecked(false);
            ageSeniorCheckBox.setChecked(false);
        } else if (ageAdultCheckBox.isChecked()) {
            ageSeniorCheckBox.setChecked(false);
            ageYoungCheckBox.setChecked(false);
        } else if (ageSeniorCheckBox.isChecked()) {
            ageYoungCheckBox.setChecked(false);
            ageAdultCheckBox.setChecked(false);
        }
    }

    /**
     * This method is called when the getPoints button is clicked to show the toast message with the results.
     */
    public void getPoints(View view) {
        RadioButton brussels_button = (RadioButton) findViewById(R.id.brusselsRadiobutton);
        if (brussels_button.isChecked()) {
            score = score + 2;
            correctanswers = correctanswers + 1;
        }
        RadioButton moscow_button = (RadioButton) findViewById(R.id.moscowRadiobutton);
        if (moscow_button.isChecked()) {
            score = score + 2;
            correctanswers = correctanswers + 1;
        }
        RadioButton rabat_button = (RadioButton) findViewById(R.id.rabatRadiobutton);
        if (rabat_button.isChecked()) {
            score = score + 2;
            correctanswers = correctanswers + 1;
        }
        RadioButton ancara_button = (RadioButton) findViewById(R.id.ancaraRadiobutton);
        if (ancara_button.isChecked()) {
            score = score + 2;
            correctanswers = correctanswers + 1;
        }
        RadioButton athens_button = (RadioButton) findViewById(R.id.athensRadiobutton);
        if (athens_button.isChecked()) {
            score = score + 2;
            correctanswers = correctanswers + 1;
        }
        EditText edittext = (EditText) findViewById(R.id.editQuestionText);
        String text = edittext.getText().toString().trim();
        if (text.equals("Tokio") || text.equals("tokio")) {
            score = score + 2;
            correctanswers = correctanswers + 1;
        }
        CheckBox checkB1 = (CheckBox) findViewById(R.id.checkbox1);
        CheckBox checkB2 = (CheckBox) findViewById(R.id.checkbox2);
        CheckBox checkB3 = (CheckBox) findViewById(R.id.checkbox3);
        CheckBox checkB4 = (CheckBox) findViewById(R.id.checkbox4);
        if (checkB2.isChecked() && checkB3.isChecked() && (!checkB1.isChecked() && (!checkB4.isChecked()))) {
            score = score + 2;
            correctanswers = correctanswers + 1;
        }
        EditText userName = (EditText) findViewById(R.id.nameField);
        String name = userName.getText().toString();
        if ((score >= 5) && ageYoungCheckBox.isChecked()) {
            Toast.makeText(this, "Dear " + name + ", you are SO YOUNG! Yet, you got " + score + " points!!!!! Hoorrayyy!!! You answered: " + correctanswers + " questions correctly!", Toast.LENGTH_LONG).show();
            score = 0;
        } else if ((score >= 5) && ageAdultCheckBox.isChecked()) {
            Toast.makeText(this, "Dear " + name + ", you are at your best age for wisdom and knowledge! You got " + score + " points! Keep up!!! You answered: " + correctanswers + " questions correctly!", Toast.LENGTH_LONG).show();
            score = 0;
        } else if ((score >= 5) && ageSeniorCheckBox.isChecked()) {
            Toast.makeText(this, "Dear " + name + ", you are so mature, you gained all this knowledge troughout the years! You got " + score + " points!!! Keep up the great job! You answered: " + correctanswers + " questions correctly!", Toast.LENGTH_LONG).show();
            score = 0;
        } else {
            Toast.makeText(this, "Dear " + name + ", you could have done better.... You got " + score + " points! Please do some reading! You answered: " + correctanswers + " questions correctly!", Toast.LENGTH_LONG).show();
            score = 0;
        }
    }
}